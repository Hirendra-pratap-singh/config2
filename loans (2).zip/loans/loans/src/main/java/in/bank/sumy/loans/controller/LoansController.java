package in.bank.sumy.loans.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.bank.sumry.loans.model.Customer;
import in.bank.sumry.loans.model.Loans;
import in.bank.sumry.loans.repository.LoanRepository;



@RestController
public class LoansController<loansRepository> {

	@Autowired
	private LoanRepository loansRepository;
	@PostMapping("/loans")	
	@SuppressWarnings("hiding")

	
	public <loansRepository> List<Loans> getCardDetails(@RequestBody Customer customer){
		
		List<Loans> loans=loansRepository.findByCustomerId(customer.getCustomerId());
	    
		return loans;
	}
}

