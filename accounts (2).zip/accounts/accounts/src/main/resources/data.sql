DROP Table IF EXISTS customers;
DROP Table IF EXISTS accounts;

CREATE TABLE customers (
customer_id int AUTO_INCREMENT PRIMARY KEY,
name varchar(100) NOT NULL,
mobile_number varchar(10) NOT NULL,
email_id varchar(100) NOT NULL,
created_date date DEFAULT NULL
);

CREATE TABLE accounts (
customer_id int NOT NULL,
account_number int AUTO_INCREMENT PRIMARY KEY,
account_type varchar(100) NOT NULL,
branch varchar(10) NOT NULL,
created_date date DEFAULT NULL
);

INSERT INTO `customers`(`name`,`mobile_number`,`email_id`,`created_date`) VALUES ('skill',9876543210,'testskill@gmail.com',CURDATE());

INSERT INTO `accounts`(`customer_id`,`account_number`,`account_type`,`branch`,`created_date`) VALUES (123,9865,'savings','bhopal',CURDATE());



