package in.bank.cards.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Customer {
@Id

@GeneratedValue(strategy=GenerationType.AUTO)

@Column(name="customer_id")
private int customerId;

@Column(name="name")
private String name;

@Column(name="mobile_number")
private String mobileNumber;

@Column(name="email_id")
private String emailID;

@Column(name="created_date")
private LocalDate createdDate;

public int getCustomerId() {
	return customerId;
}

public void setCustomerId(int customerId) {
	this.customerId = customerId;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getMobileNumber() {
	return mobileNumber;
}

public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}

public String getEmailID() {
	return emailID;
}

public void setEmailID(String emailID) {
	this.emailID = emailID;
}

public LocalDate getCreatedDate() {
	return createdDate;
}

public void setCreatedDate(LocalDate createdDate) {
	this.createdDate = createdDate;
}

@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", name=" + name + ", mobileNumber=" + mobileNumber + ", emailID="
			+ emailID + ", createdDate=" + createdDate + ", getCustomerId()=" + getCustomerId() + ", getName()="
			+ getName() + ", getMobileNumber()=" + getMobileNumber() + ", getEmailID()=" + getEmailID()
			+ ", getCreatedDate()=" + getCreatedDate() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
			+ ", toString()=" + super.toString() + "]";
};


	
}
